# Assignment 16 : SVM, Trees, Ensembles,Validation And Unsupervised Learning

## This assignment Covers
- Support Vactor Machine (SVM)
- Decision Tree Algorithm
- Train vs Validation vs Test And Cross-Validation
- Ensemble Learning (Bagging Vs Boosting)
- Random Forest (Bagging)


### All Task covert in 
### All_Task-16.ipynb



#  How to Run
## instruction on how to test and run the code.
## Steps to run code :
## To execute these scripts, you must have python 3 installed on your system. Open your terminal or command prompt and run the following command:
## python All_Task16.ipynb  .